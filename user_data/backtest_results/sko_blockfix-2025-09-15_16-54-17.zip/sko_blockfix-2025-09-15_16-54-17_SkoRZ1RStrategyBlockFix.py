
# SkoRZ1RStrategyBlockFix.py
# Version: 0.1.1 (2025-09-15)
# Change: Ensure sig_green is boolean (fill NaN, astype(bool)) to avoid "~" on float Series.
#
from typing import Any, Dict, Optional
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from freqtrade.strategy.interface import IStrategy
from freqtrade.strategy import IntParameter, DecimalParameter

class SkoRZ1RStrategyBlockFix(IStrategy):
    timeframe = '5m'
    can_short = True

    minimal_roi = { "0": 10 }
    stoploss = -0.99
    trailing_stop = False

    DIAG_LOG = True

    zscore_lookback = IntParameter(50, 300, default=100, space='indicator', optimize=False)
    zscore_threshold = DecimalParameter(1.0, 4.0, default=2.0, decimals=1, space='indicator', optimize=False)

    signal_lag_bars = IntParameter(1, 1, default=1, space='indicator', optimize=False)

    plot_config = {
        "main_plot": {
            "sko_entry_long":  {"type": "scatter"},
            "sko_stop_long":   {"type": "scatter"},
            "sko_take_long":   {"type": "scatter"},
            "sko_entry_short": {"type": "scatter"},
            "sko_stop_short":  {"type": "scatter"},
            "sko_take_short":  {"type": "scatter"},
        },
        "subplots": {
            "SKO z": { "sko_zscore": {"type": "line"} }
        }
    }

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._trade_state: Dict[int, Dict[str, Any]] = {}

    @staticmethod
    def _series_color(close: pd.Series, open_: pd.Series) -> pd.Series:
        return (close > open_)

    def _compute_indicator_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        need_calc = not {"sko_entry_long","sko_entry_short","sko_stop_long","sko_stop_short","sko_take_long","sko_take_short","sko_zscore"}.issubset(df.columns)
        if not need_calc:
            return df

        vol = df["volume"].astype("float64")
        lb  = int(self.zscore_lookback.value)
        mean = vol.rolling(lb, min_periods=lb).mean()
        std  = vol.rolling(lb, min_periods=lb).std(ddof=0)
        z = (vol - mean) / (std.replace(0, np.nan))
        df["sko_zscore"] = z

        thr = float(self.zscore_threshold.value)
        is_sko = (z > thr).fillna(False)

        green = self._series_color(df["close"], df["open"])
        s = int(self.signal_lag_bars.value)

        # Make sure sig_green is boolean (no NaN)
        sig_green = green.shift(-s).fillna(False).astype(bool)

        rng = (df["high"] - df["low"])
        entry_price = df["open"].shift(-s)

        valid = is_sko & entry_price.notna()

        df["sko_entry_long"]  = np.where(valid & sig_green, entry_price, np.nan)
        df["sko_stop_long"]   = np.where(valid & sig_green, df["low"], np.nan)
        df["sko_take_long"]   = np.where(valid & sig_green, entry_price + rng, np.nan)

        df["sko_entry_short"] = np.where(valid & (~sig_green), entry_price, np.nan)
        df["sko_stop_short"]  = np.where(valid & (~sig_green), df["high"], np.nan)
        df["sko_take_short"]  = np.where(valid & (~sig_green), entry_price - rng, np.nan)

        return df

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        df = dataframe.copy()
        df = self._compute_indicator_fields(df)
        return df

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        df = dataframe
        df.loc[:, "enter_long"]  = df["sko_entry_long"].notna()
        df.loc[:, "enter_short"] = df["sko_entry_short"].notna()
        df.loc[:, "enter_tag"] = np.where(df["enter_long"], "SKO_LONG",
                                   np.where(df["enter_short"], "SKO_SHORT", ""))
        return df

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[:, "exit_long"] = 0
        dataframe.loc[:, "exit_short"] = 0
        return dataframe

    def custom_exit(self, pair: str, trade, current_time: datetime,
                    current_rate: float, current_profit: float, **kwargs) -> Optional[str]:
        try:
            df, _ = self.dp.get_analyzed_dataframe(pair=pair, timeframe=self.timeframe)
        except Exception:
            return None

        if df is None or df.empty:
            return None

        entry_dt = trade.open_date_utc
        if entry_dt.tzinfo is None:
            entry_dt = entry_dt.replace(tzinfo=timezone.utc)
        try:
            entry_pos = df.index.get_loc(entry_dt)
        except KeyError:
            entry_pos = int(df.index.searchsorted(entry_dt))

        tid = int(getattr(trade, "trade_id", getattr(trade, "id", 0)))
        st = self._trade_state.get(tid)
        if st is None:
            levels = self._compute_levels_from_sko(df, entry_pos, trade)
            if levels is None:
                return None
            self._trade_state[tid] = levels
            if self.DIAG_LOG:
                self._diag_log_trade_open(pair, tid, levels)

        levels = self._trade_state.get(tid)
        if levels is None:
            return None

        row = df.iloc[-1]
        chigh = float(row["high"])
        clow  = float(row["low"])

        if levels["is_long"]:
            if clow <= levels["sl"]:
                self._diag_log_exit(pair, tid, "stop_loss", levels, row)
                self._trade_state.pop(tid, None)
                return "stop_loss"
            if chigh >= levels["tp"]:
                self._diag_log_exit(pair, tid, "take_profit", levels, row)
                self._trade_state.pop(tid, None)
                return "take_profit"
        else:
            if chigh >= levels["sl"]:
                self._diag_log_exit(pair, tid, "stop_loss", levels, row)
                self._trade_state.pop(tid, None)
                return "stop_loss"
            if clow <= levels["tp"]:
                self._diag_log_exit(pair, tid, "take_profit", levels, row)
                self._trade_state.pop(tid, None)
                return "take_profit"

        return None

    def _compute_levels_from_sko(self, df: pd.DataFrame, entry_pos: int, trade) -> Optional[Dict[str, Any]]:
        signal_lag = int(self.signal_lag_bars.value)
        sko_pos = entry_pos - (signal_lag + 1)
        if sko_pos < 0 or sko_pos >= len(df):
            return None

        sko = df.iloc[sko_pos]
        signal = df.iloc[sko_pos + signal_lag] if (sko_pos + signal_lag) < len(df) else None
        entry_row = df.iloc[entry_pos] if entry_pos < len(df) else None

        if entry_row is None:
            return None

        R = float(sko["high"] - sko["low"])
        if not np.isfinite(R) or R <= 0:
            return None

        if signal is not None:
            sig_green = bool(signal["close"] > signal["open"])
        else:
            sig_green = bool(entry_row["open"] >= sko["close"])

        is_long = sig_green
        entry_open_fact = float(entry_row["open"])
        if is_long:
            sl = float(sko["low"])
            tp = entry_open_fact + R
        else:
            sl = float(sko["high"])
            tp = entry_open_fact - R

        if signal is not None:
            sko_green = bool(sko["close"] > sko["open"])
            is_reversal = (sko_green != sig_green)
            ideal_entry = float(signal["close"] if is_reversal else signal["open"])
        else:
            is_reversal = False
            ideal_entry = float(entry_open_fact)

        return dict(
            sko_pos=sko_pos,
            sko_high=float(sko["high"]),
            sko_low=float(sko["low"]),
            R=float(R),
            entry_pos=entry_pos,
            entry_open_fact=float(entry_open_fact),
            is_long=bool(is_long),
            is_reversal=bool(is_reversal),
            ideal_entry=float(ideal_entry),
            sl=float(sl),
            tp=float(tp),
        )

    def _diag_log_trade_open(self, pair: str, tid: int, lv: Dict[str, Any]) -> None:
        try:
            self.logger.info(
                f"[OPEN] {pair} T#{tid} "
                f"{'LONG' if lv['is_long'] else 'SHORT'} "
                f"mode={'REV' if lv['is_reversal'] else 'CONT'} | "
                f"ideal_entry={lv['ideal_entry']:.6f} fact_entry={lv['entry_open_fact']:.6f} | "
                f"SKO H/L={lv['sko_high']:.6f}/{lv['sko_low']:.6f} R={lv['R']:.6f} | "
                f"SL={lv['sl']:.6f} TP={lv['tp']:.6f}"
            )
        except Exception:
            pass

    def _diag_log_exit(self, pair: str, tid: int, reason: str, lv: Dict[str, Any], row: pd.Series) -> None:
        try:
            self.logger.info(
                f"[EXIT] {pair} T#{tid} {reason.upper()} | "
                f"bar H/L={float(row['high']):.6f}/{float(row['low']):.6f} | "
                f"SL={lv['sl']:.6f} TP={lv['tp']:.6f}"
            )
        except Exception:
            pass
